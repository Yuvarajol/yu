<?php
$username=$_POST['username'];
$email=$_POST['email'];
$password=$_POST['password'];

$conn = new mysqli('sql110.ezyro.com','ezyro_33975484','','ezyro_33975484_yuvaraj');
if($conn->connect_error){
	die('connection failed :'.$conn->connect_error);
}else{
	 $stmt = $conn->prepare("insert into register(username,email,password)values(?,?,?)");
	 $stmt->bind_param("sss",$username,$email,$password);
	 $stmt->execute();
	 echo"registration successfully";
	 $stmt->close();
	 $conn->close();
} 
?>
