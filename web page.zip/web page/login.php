<?php
$email=$_POST['email'];
$password=$_POST['password'];

$conn = new mysqli('localhost','id20577045_root','9^Cwu\gf<xZ#>L>d','id20577045_register');
if($conn->connect_error){
	echo"$conn->connect_error";
	die('connection failed :'.$conn->connect_error);
}else{
	 $stmt = $conn->prepare("select * from registration where email = ?" );
	 $stmt->bind_param("s" , $email);
	 $stmt->execute();
	 $stmt_result = $stmt->get_result();
	 if($stmt_result->num_rows>0){
		 $data = $stmt_result->fetch_assoc();
		 if($data['password']===$password){
			 echo"<h2>login successfully</h2>";
		 }else{
			 echo"<h2>invalid emailor password </h2>";
		 }
	 }
}
?>